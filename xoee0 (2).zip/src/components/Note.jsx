import React from "react";

function Note(){
  return( 
   <div className="note" >
     <h1>Javascript And React.js</h1>
     <p>It is a good proagram conducted by shapeAI.It give wonderfull experience to me.It give a lifetime experience.While see the sir'Shaurya sinha' , I get the confident to face the problem.I should THANK to all people behind shapeAI for to gve this good moments</p>
  </div>);
}
export default Note;